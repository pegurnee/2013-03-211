// ****************************************************************
//   ManageAccounts.java
//   Use Account class to create and manage Sally and Joe's bank accounts
public class ManageAccounts
{
    public static void main(String[] args)
    {
		Account acct1, acct2;
	
		//create account1 for Sally with $1000
		acct1 = new Account(1000, "Sally", 1111);
		
		//create account2 for Joe with $500
		
		//deposit $100 to Joe's account
		
		//print Joe's new balance (use getBalance())
		
		//withdraw $50 from Sally's account
		
		//print Sally's new balance (use getBalance())
		
		//charge fees to both accounts
		
		//change the name on Joe's account to Joseph
		
		//print summary for both accounts
		
    }
}

