// ****************************************************************
// Dates.java
// Determine whether a 2nd-millenium date entered by the user is valid
// ****************************************************************
import java.util.Scanner;;

public class Dates
{
    public static void main(String[] args)
    {
		int month, day, year;   		//date read in from user
		int daysInMonth;        		//number of days in month read in 
		boolean monthValid, yearValid, dayValid;  //true if input is valid
		boolean leapYear;  			//true if user's year is a leap year
	
		//Get integer month, day, and year from user
	
		//Check to see if month is valid
	
		//Check to see if year is valid
	
		//Determine whether it's a leap year
	
		//Determine number of days in month
	
		//User number of days in month to check to see if day is valid
	
		//Determine whether date is valid and print appropriate message
    }
}
