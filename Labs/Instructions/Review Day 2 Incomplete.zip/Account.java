//*******************************************************
// Account.java
// A bank account class with methods to deposit to, withdraw from,
// change the name on, charge a fee to, and print a summary of the account.
import java.text.NumberFormat;
public class Account
{
  private double balance;
  private String name;
  private long acctNum;
  
  private static int numAccounts;

  // Constructor -- initializes balance, owner, and account number
  public Account(double balance, String name, long acctNum)
  {
    this.balance = balance;
    this.name = name;
    this.acctNum = acctNum;
    numAccounts++;
  }

  // Checks to see if balance is sufficient for withdrawal.
  // If so, decrements balance by amount; if not, prints message.
  public void withdraw(double amount)
  {
    if (balance >= amount)
       balance -= amount;
    else
       System.out.println("Insufficient funds");
  }

  // Adds deposit amount to balance
  public void deposit(double amount)
  {
    balance += amount;
  }

  // Returns balance.
  public double getBalance()
  {
    return balance;
  }

  // Returns the account number
   public long getAcctNumber()
  {
    return acctNum;
  }

  // Returns a string containing the name, account number, and balance.
  public String toString()
  {
	NumberFormat usmoney = NumberFormat.getCurrencyInstance(); 
	  
	return "Account Name: " + name + "\nAccount Number: " + acctNum + "\nBalance:" + usmoney.format(balance);
  }

  // Deducts $10 service fee
  public double chargeFee() 
  {
	  balance -= 10;
	  return balance;
	
  }

  // Changes the name on the account 
  public void changeName(String newName)
  {
	name = newName;
  }
  
  public static int getNumAccounts()
  {
	  return numAccounts;
  }
  
  public void close() 
  {
	  this.name += "CLOSED";
	  this.balance = 0;
	  numAccounts--;
  }
  
  public static Account consolidate(Account account1, Account account2)
  {
	  if (account1.name.equals(account2.name) && account1.acctNum != account2.acctNum)
	  {
		  Account newAcct = new Account(account1.balance + account2.balance, account1.name, account1.acctNum + account2.acctNum);
		  account1.close();
		  account2.close();
		  return newAcct;
	  }
	  else
	  {
		  System.out.println("Cannot consolidate accounts");
		  return null;
	  }
		 
	  
  }
  
}


