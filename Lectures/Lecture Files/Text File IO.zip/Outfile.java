import java.io.*;
import java.util.*;
public class Outfile {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter string: ");
		String phrase = scan.nextLine();
		
		PrintWriter outf = null;
		try
		{
			outf = new PrintWriter(new FileOutputStream("leter.txt", true));
			outf.println(phrase);
			
		}
		catch (FileNotFoundException ex)
		{
			System.out.println(ex.getMessage());
			System.exit(1);
		}
		finally
		{
			outf.close();
		}
		
	}

}
