import java.io.*;
import java.util.Scanner;
public class StringText {

	public static void main (String[] args){
		Scanner txtfile = null;
		File afile = null;
		
		try {
			afile = new File ("data.txt");
			txtfile = new Scanner (afile);

			System.out.println("Length of file: " + afile.length());
			System.out.println("Actual name of file: " + afile.getName());
			while (txtfile.hasNext()) {
				System.out.println(txtfile.nextLine());
			}
			
		}
		catch (FileNotFoundException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		
		finally {
			txtfile.close();

		}
	}
	
}
