
public interface Nameable {
	public void setName(String s);
	public String getName();
}
