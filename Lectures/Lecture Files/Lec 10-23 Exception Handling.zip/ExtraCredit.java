import java.util.*;
public class ExtraCredit {

	/**
	 * 
	 * Write a Java application that will prompt the user for an
	 * integer and display a message
	 * that tells whether the number is an odd or even number.
	 * Handle the following exceptions:
	 * 	InputMismatchException
	 *  NegativeNumberException
	 * and terminate the program if an exception is thrown.
	 * 
	 */


	/* 
	 * Modify your program to prompt for an even number and throw an
	 * 	OddNumberException if the user entered an odd number.
	 * Create the OddNumberException class.
	 */
	public static void main (String[] arg) {
		
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter an integer: ");
		
		try {
			int num = scan.nextInt();
			
			if (num < 0)
				throw new NegativeNumberException("Negative number.");
		}
		catch(InputMismatchException ex) {
			System.out.println("Not an integer... Goodbye.");
			System.exit(1);
		}

		catch(NegativeNumberException ex) {
			System.out.print(ex);
		}
	}
}






















