import java.util.Scanner;
public class DivideByZeroExceptionWithThrow {

		public static void main(String[] args) {
			Scanner scan = new Scanner(System.in);
			boolean exception = false;
			int quotient = 0;
			do {
				System.out.print("Enter two integers to divide: ");
				int num1 = scan.nextInt();
				int num2 = scan.nextInt();

				try {
					quotient = divide(num1, num2);
					exception = true;
				}
				catch (ArithmeticException ex) {
					System.out.println(ex);
					System.out.println("Invalid divisor. Try again...");
					exception = false;
				}
				
			}while (!exception);
			System.out.println("Quotient = " + quotient);

		}

	public static int divide(int n1, int n2) {
		if (n2 == 0)
			throw new ArithmeticException("Divide by zero.");
		return n1/n2;
	}
}
