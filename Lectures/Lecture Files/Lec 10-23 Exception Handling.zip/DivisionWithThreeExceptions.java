import java.util.*;
public class DivisionWithThreeExceptions {
	public static void main(String[] args) {

		Scanner scan = new Scanner (System.in);
		boolean done = false;
		
		while (!done) {
			System.out.print("Enter 2 integers: ");
			try {
				int num1 = scan.nextInt();
				int num2 = scan.nextInt();
				
				if (num2 == 0)
					throw new ArithmeticException("Cannot divide by zero!");
			
				System.out.println(num1 + " divided by " + num2 + " = " +
						(num1 / num2));
				done = true;
			}
			
			catch (ArithmeticException ex) {
				System.out.println("Exception: divisor cannot be zero.");
				System.out.println(ex.getMessage());
			}
			
			catch (InputMismatchException ex) {
				System.out.println("You entered a non-integer. Try again...");
				scan.nextLine();
			}
		}
		
		System.out.println("Last part of the program...");
	}

}
