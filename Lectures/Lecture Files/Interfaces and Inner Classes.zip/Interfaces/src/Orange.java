
public class Orange implements Edible{
	@Override
	public  String howToEat(){
		return "Peel it first.";
	}
}
