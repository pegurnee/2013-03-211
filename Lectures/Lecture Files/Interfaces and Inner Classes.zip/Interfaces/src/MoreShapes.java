
public class MoreShapes {

	public static void main(String[] args) {

		Square sq = new Square(5.0);
		System.out.println("Area of square = " + sq.area());
		System.out.println("Perimeter of square = " + sq.perimeter());
		
	}

}
