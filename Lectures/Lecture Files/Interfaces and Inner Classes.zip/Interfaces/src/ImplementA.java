
public class ImplementA implements Weeks
{
	public String firstDayOfWeekStr() {
		return SUNDAY;
	}
	
	public int dayOfWeek(String day) {
		//+2 EC pts
		// Write the body for this method
		// "Sunday" = 1, ..., "Saturday" = 7, Invalid string = -1
		
	}
	
	
}
