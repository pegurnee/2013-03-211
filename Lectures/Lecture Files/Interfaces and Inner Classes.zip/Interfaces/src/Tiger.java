
public class Tiger extends Animal{
	
	@Override
	public String sound(){
		return "Rrooaarr!";
	}

}
