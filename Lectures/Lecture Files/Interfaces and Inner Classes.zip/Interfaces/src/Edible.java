
public interface Edible {
	
	 String howToEat();

}
