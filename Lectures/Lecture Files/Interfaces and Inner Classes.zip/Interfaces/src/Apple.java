
public class Apple implements Edible{
	@Override
	public  String howToEat() {
		return ("Make apple cider.");
	}
}
