
public class Carrier1 implements NumberCarrier{

	private int number;
    public void setNumber(int value)
    {
        number = 2*value;
    }
    public int getNumber( )
    {
        return number;
    }
}
